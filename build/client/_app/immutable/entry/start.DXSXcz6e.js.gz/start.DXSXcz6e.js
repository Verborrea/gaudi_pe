import{a as t}from"../chunks/entry.D6_r9q0Q.js";export{t as start};
